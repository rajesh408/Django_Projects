from __future__ import unicode_literals
from django.db import models

# Create your models here.
class Product(models.Model):
    prod_name=models.CharField(max_length=30)
    prod_price=models.DecimalField(max_digits=10,decimal_places=2)
    prod_qty=models.IntegerField()

    class Meta:
        db_table="product"
