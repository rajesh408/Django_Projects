from django.shortcuts import render
from djangomodelapp.form import ProdForm

# Create your views here.

def index(request):
    prod=ProdForm()
    return render(request, "index.html", {'form':prod})