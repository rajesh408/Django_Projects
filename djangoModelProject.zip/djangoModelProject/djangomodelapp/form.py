from django import forms
from djangomodelapp.models import Product

class ProdForm(forms.ModelForm):
    class Meta:
        model=Product
        fields="__all__"