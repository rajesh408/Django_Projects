from django.apps import AppConfig


class DjangomodelappConfig(AppConfig):
    name = 'djangomodelapp'
